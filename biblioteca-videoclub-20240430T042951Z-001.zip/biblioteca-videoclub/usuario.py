class Usuario():
    def __init__(self, dni, nombre, direccion, telefono):
        self.__dni = dni
        self.__nombre = nombre
        self.__direccion = direccion
        self.__telefono = telefono
        self.__situacion = "L"
        self.__codigo = ""

    def get_dni(self):
        return self.__dni
    
    def set_dni(self, newdni):
        self.__dni = newdni

    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre

    def get_direccion(self):
        return self.__direccion
    
    def set_direccion(self, newdireccion):
        self.__direccion = newdireccion

    def get_telefono(self):
        return self.__telefono
    
    def set_telefono(self, newtelefono):
        self.__telefono = newtelefono

    def get_situacion(self):
        return self.__situacion
    
    def set_situacion(self, newsituacion):
        self.__situacion = newsituacion

    def get_codigo(self):
        return self.__codigo
    
    def set_codigo(self, newcodigo):
        self.__codigo = newcodigo

    def verDatos(self):
        pass

    def modificarDatos(self):
        pass

    def pedirBaja(self):
        pass

    def verTodas(self):
        pass

    def verDisponibles(self):
        pass

    def buscarPelicula(self):
        pass

    def alquilarPelicula(self):
        pass

    def devolverPelicula(self):
        pass