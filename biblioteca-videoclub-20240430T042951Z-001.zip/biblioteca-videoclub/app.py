class App():
    def __init__(self):
        self.__usuarios = []
        self.__peliculas = []
    
    def get_usuarios(self):
        return self.__usuarios

    def set_usuarios(self, newusers):
        self.__usuarios = newusers

    def get_peliculas(self):
        return self.__peliculas

    def set_peliculas(self, newpelis):
        self.__peliculas = newpelis

    def generarUser(self):
        pass

    def  borrarUser(self):
        pass

    def generarPelicula(self):
        pass

    def agregarUsuario(self, userObj):
        self.get_usuarios().append(userObj)

    def agregarPelicula(self, peliculaObj):
        self.get_peliculas().append(peliculaObj)