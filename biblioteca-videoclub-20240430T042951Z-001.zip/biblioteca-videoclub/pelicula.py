class Pelicula():
    def __init__(self, codigo, nombre, genero):
        self.__codigo = codigo
        self.__nombre = nombre
        self.__genero = genero
        self.__situacion = "L"
        self. __dni = ""
    
    def get_codigo(self):
        return self.__codigo
    
    def set_codigo(self, newcodigo):
        self.__codigo = newcodigo
    
    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre
    
    def get_genero(self):
        return self.__genero
    
    def set_genero(self, newgenero):
        self.__genero = newgenero

    def get_situacion(self):
        return self.__situacion
    
    def set_situacion(self, newsituacion):
        self.__situacion = newsituacion

    def get_dni(self):
        return self.__dni
    
    def set_dni(self, newdni):
        self.__dni = newdni