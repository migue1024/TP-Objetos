class Producto():
    def __init__(self, nombre, precio):
        self.__nombre = nombre
        self.__precio = precio

    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre

    def get_precio(self):
        return self.__precio
    
    def set_precio(self, newprecio):
        self.__precio = newprecio