class Bazar():
    def __init__(self):
        self.__articulos = []
    
    def get_articulos(self):
        return self.__articulos
    
    def set_articulos(self, newarticulos):
        self.__articulos = newarticulos

    def liquidarSueldo(self, empleadoObj):
        print(empleadoObj.get_sueldo())