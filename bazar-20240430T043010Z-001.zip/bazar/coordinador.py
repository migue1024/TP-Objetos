from empleado import Empleado

class Coordinador(Empleado):
    def __init__(self, nombre, apellido, dni, sueldo, comision):
        super().__init__(nombre, apellido, dni, sueldo, comision)

    def coordinar(self):
        print("Estoy coordinado")