from empleado import Empleado

class EmpleadoDeposito(Empleado):
    def __init__(self, nombre, apellido, dni, sueldo, comision):
        super().__init__(nombre, apellido, dni, sueldo, comision)
    
    def irDeposito(self):
        print("Estoy yendo al deposito")