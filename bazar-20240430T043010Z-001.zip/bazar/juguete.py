from producto import Producto

class Juguete(Producto):
    def __init__(self, nombre, precio, edadRecomendad):
        super().__init__(nombre, precio)
        self.__edadRecomendad = edadRecomendad

    def get_edadRecomendad(self):
        return self.__edadRecomendad
    
    def set_edadRecomendada(self, newedad):
        self.__edadRecomendad = newedad