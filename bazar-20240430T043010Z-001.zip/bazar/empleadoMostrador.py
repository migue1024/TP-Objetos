from empleado import Empleado

class EmpleadorMostrador(Empleado):
    def __init__(self, nombre, apellido, dni, sueldo, comision, caja):
        super().__init__(nombre, apellido, dni, sueldo, comision)
        self.__caja = caja

    def get_caja(self):
        return self.__caja
    
    def set_caja(self, newcaja):
        self.__caja = newcaja

    def cobrar(self, productoObj):
        self.set_caja(self.get_caja() + productoObj.get_precio())
        print("Producto cobrado satisfactoriamente")
    