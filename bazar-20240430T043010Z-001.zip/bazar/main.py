from bazar import Bazar
from empleado import Empleado
from vajilla import Vajilla
from empleadoMostrador import EmpleadorMostrador


empleadoM1 = Empleado("Hugo", "Peña", 36720733, 1000000, 0)
vajilla1 = Vajilla("Plato", 200, "Porcelana")
print(empleadoM1.get_comision())
empleadoM1.venderArticulo(vajilla1)
print(empleadoM1.get_comision())