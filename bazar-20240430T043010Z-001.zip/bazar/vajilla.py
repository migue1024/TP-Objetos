from producto import Producto

class Vajilla(Producto):
    def __init__(self, nombre, precio, material):
        super().__init__(nombre, precio)
        self.__material = material

    def get_material(self):
        return self.__material
    
    def set_material(self, newmaterial):
        self.__material = newmaterial