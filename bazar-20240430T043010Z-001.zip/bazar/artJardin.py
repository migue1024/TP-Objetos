from producto import Producto

class ArtJardin(Producto):
    def __init__(self, nombre, precio, usoProfesional):
        super().__init__(nombre, precio)
        self.__usoProfesional = usoProfesional

    def get_usoProfesional(self):
        return self.__usoProfesional
    
    def set_usoProfesional(self, newuso):
        self.__usoProfesional = newuso