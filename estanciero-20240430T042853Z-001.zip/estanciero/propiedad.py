class Propiedad():
    def __init__(self, nombre, precioVenta, precioAlquiler, duenio):
        self.__nombre = nombre
        self.__precioVenta = precioVenta
        self.__precioAlquiler = precioAlquiler
        self.__duenio = duenio

    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre

    def get_precioVenta(self):
        return self.__precioVenta
    
    def set_precioVenta(self, newprecioventa):
        self.__precioVenta = newprecioventa

    def get_precioAlquiler(self):
        return self.__precioAlquiler
    
    def set_precioAlquiler(self, newprecioalquiler):
        self.__precioAlquiler = newprecioalquiler

    def get_duenio(self):
        return self.__duenio
    
    def set_duenio(self, newduenio):
        self.__duenio = newduenio