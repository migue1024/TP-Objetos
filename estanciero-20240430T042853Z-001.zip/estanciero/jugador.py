class Jugador():
    def __init__(self, nombre, avatar):
        self.__nombre = nombre
        self.__avatar = avatar
        self.__propiedades = []
        self.__dinero = 500000
        self.__casillero = 0
        self.__estaActivo = False
    #getters and setters
    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre

    def get_avatar(self):
        return self.__avatar
    
    def set_avatar(self, newavatar):
        self.__avatar = newavatar

    def get_propiedades(self):
        return self.__propiedades
    
    def set_propiedades(self, newpropiedades):
        self.__propiedades = newpropiedades

    def get_dinero(self):
        return self.__dinero
    
    def set_dinero(self, newdinero):
        self.__dinero = newdinero

    def get_casillero(self):
        return self.__casillero
    
    def set_casillero(self, newcasillero):
        self.__casillero = newcasillero

    def get_estaActivo(self):
        return self.__estaActivo
    
    def set_estaActivo(self, newactivo):
        self.__estaActivo = newactivo
    #methods
    def comprarPropiedad(self, propiedad_obj):
        if propiedad_obj.get_duenio is Juego():
            if self.get_dinero() >= propiedad_obj.get_precioVenta():
                self.set_dinero(self.get_dinero() - propiedad_obj.get_precioVenta())
                lista = self.get_propiedades()
                lista.append(propiedad_obj)
                self.set_propiedades(lista)
                #self.get_propiedades().append(propiedad_obj)
                propiedad_obj.get_duenio().set_dinero(propiedad_obj.get_duenio().get_dinero() + propiedad_obj.get_precioVenta())
                propiedad_obj.get_duenio().get_propiedades().remove(propiedad_obj)
                propiedad_obj.set_duenio(self)
            else:
                self.alquilarPropiedad()
        else:
            if self.get_dinero() >= propiedad_obj.get_precioAlquiler():
                self.set_dinero(self.get_dinero() - propiedad_obj.get_precioAlquiler())
                propiedad_obj.get_duenio().set_dinero(propiedad_obj.get_duenio().get_dinero() + propiedad_obj.get_precioAlquiler())
            else:
                self.gameOver()


    def alquilarPropiedad(self, propiedad_obj):
        if self.get_dinero() >= propiedad_obj.get_precioAlquiler():
            self.set_dinero(self.get_dinero() - propiedad_obj.get_precioAlquiler())
            propiedad_obj.get_duenio().set_dinero(propiedad_obj.get_duenio().get_dinero() + propiedad_obj.get_precioAlquiler())
        else:
            self.gameOver()
    
    def avanzarCasillero(self, dado):
        if self.get_estaActivo() and self.isAlive():
            self.set_casillero(self.get_casillero() + dado)
            self.set_estaActivo(False)

    def isAlive(self):
        if self.get_dinero() <= 0:
            return False
        else:
            return True

    def gameOver(self):
        pass

    # def isActive(self, turno):
    #     if turno == 1:
    #         return True
    #     else:
    #         return False