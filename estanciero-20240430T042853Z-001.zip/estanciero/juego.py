import random

class Juego():
    def __init__(self, listaJugadores, listaPropiedades):
        # atributos
        self.__jugadores = listaJugadores
        self.__propiedades = listaPropiedades
        self.__dinero = 0
    # getters y setters
    def get_jugadores(self):
        return self.__jugadores
    
    def set_jugadores(self, newjugadores):
        self.__jugadores = newjugadores

    def get_propiedades(self):
        return self.__propiedades
    
    def set_propiedades(self, newpropiedades):
        self.__propiedades = newpropiedades

    def get_dinero(self):
        return self.__dinero
    
    def set_dinero(self, newdinero):
        self.__dinero = newdinero
    #methods
    def tirarDado(self):
        return random.randint(1,6)