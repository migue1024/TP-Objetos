class Mapa():
    def __init__(self, combinacion):
        self.__combinacion = combinacion

    def get_combinacion(self):
        return self.__combinacion
    
    def set_combinacion(self, newcombinacion):
        self.__combinacion = newcombinacion