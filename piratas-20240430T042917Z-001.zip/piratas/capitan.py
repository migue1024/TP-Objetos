import random

from mapa import Mapa

class Capitan():
    def __init__(self, nombre):
        self.__nombre = nombre
        self.__tesoro = []
        self.__loro = None
        self.__tripulacion = []
        self.__mapas = []
        self.__barco = None
        self.__estaVivo = True

    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre
    
    def get_tesoro(self):
        return self.__tesoro
    
    def set_tesoro(self, newtesoro):
        self.__tesoro = newtesoro

    def get_loro(self):
        return self.__loro
    
    def set_loro(self, newloro):
        self.__loro = newloro

    def get_tripulacion(self):
        return self.__tripulacion
    
    def set_tripulacion(self, newtripulacion):
        self.__tripulacion = newtripulacion

    def get_mapas(self):
        return self.__mapas
    
    def set_mapas(self, newmapas):
        self.__mapas = newmapas

    def get_barco(self):
        return self.__barco
    
    def set_barco(self, newbarco):
        self.__barco = newbarco

    def get_estaVivo(self):
        return self.__estaVivo
    
    def set_estaVivo(self, newcondicion):
        self.__estaVivo = newcondicion
    
    def darOrdenes(self):
        print("Estoy dando una orden")

    def enterrarTesoro(self):
        self.set_tesoro([])
        self.get_mapas().append(Mapa(random.randint(100,999)))

    def agregarTripulacion(self, pirataObj):
        self.get_tripulacion().append(pirataObj)

    def agregarTesoro(self, tesoro):
        self.get_tesoro().append(tesoro)