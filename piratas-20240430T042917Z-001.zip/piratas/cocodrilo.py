class Cocodrilo():
    def __init__(self):
        pass

    def comerCapitan(self, capitanObj):
        print(f"Me comi al Capitan {capitanObj.get_nombre()}")
        capitanObj.set_estaVivo(False)