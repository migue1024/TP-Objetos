from pirata import Pirata

class PirataVolador(Pirata):
    def __init__(self, nombre):
        super().__init__(nombre)
    
    def volar(self):
        print("Estoy volando")