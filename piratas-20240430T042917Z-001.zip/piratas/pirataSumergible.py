from pirata import Pirata

class PirataSumergible(Pirata):
    def __init__(self, nombre):
        super().__init__(nombre)
    
    def sumergirse(self):
        print("Me estoy sumergiendo")