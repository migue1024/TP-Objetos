class Loro():
    def __init__(self):
        pass

    def constestarPregunta(self):
        print("La respuesta a tu pregunta es..")