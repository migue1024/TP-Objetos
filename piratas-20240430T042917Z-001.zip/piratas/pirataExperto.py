from pirata import Pirata

class PirataExperto(Pirata):
    def __init__(self, nombre):
        super().__init__(nombre)
    
    def leerMapa(self, mapaObj):
        print(mapaObj.get_combinacion())