from barco import Barco

class BarcoSumergible(Barco):
    def __init__(self):
        super().__init__()
    
    def sumergirse(self):
        print("Estoy sumergiendome")