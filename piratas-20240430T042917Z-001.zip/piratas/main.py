from capitan import Capitan
from loro import Loro
from barco import Barco
from cocodrilo import Cocodrilo
from pirataExperto import PirataExperto
from pirataVolador import PirataVolador
from pirataSumergible import PirataSumergible
from mapa import Mapa
