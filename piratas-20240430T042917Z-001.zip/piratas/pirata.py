class Pirata():
    def __init__(self, nombre):
        self.__nombre = nombre
    
    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre

    def luchar(self):
        print("Estoy luchando")

    def tomarRon(self):
        print("Estoy tomando ron")

    def saquear(self):
        print("Estoy saqueando")