class Barco():
    def __init__(self):
        pass

    def disparar(self):
        print("Estoy disparando")

    def navergar(self):
        print("Estoy navegando")