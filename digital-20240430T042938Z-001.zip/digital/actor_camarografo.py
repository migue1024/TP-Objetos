from empleado import Empleado

class Actor_Camarografo(Empleado):
    def __init__(self, nombre, ID, sueldo):
        super().__init__(nombre, ID, sueldo)

    def responderDirector(self, directorObj):
        print(f"Si como no, Señor {directorObj.get_nombre()}")