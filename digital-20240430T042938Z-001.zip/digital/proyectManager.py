from empleado import Empleado

class ProyectManager(Empleado):
    def __init__(self, nombre, ID, sueldo):
        super().__init__(nombre, ID, sueldo)
        self.__directores = []
        self.__diseniadores = []

    def get_directores(self):
        return self.__directores
    
    def set_directores(self, newdirectores):
        self.__directores = newdirectores
    
    def get_diseniadores(self):
        return self.__diseniadores
    
    def set_diseniadores(self, newdiseniadores):
        self.__diseniadores = newdiseniadores

    def realizarPresupuesto(self):
        print("Su presupuesto es...")