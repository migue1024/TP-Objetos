class Produccion():
    def __init__(self, nombre, fechaEstreno):
        self.__nombre = nombre
        self.__fechaEstreno = fechaEstreno
        
    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre
    
    def get_fechaEstreno(self):
        return self.__fechaEstreno
    
    def set_fechaEstreno(self, newfecha):
        self.__fechaEstreno = newfecha

    def filmar(self):
        print("Estamos filmando")

    def editar(self):
        print("Estamos editando")