from empleado import Empleado

class Director(Empleado):
    def __init__(self, nombre, ID, sueldo, guion):
        super().__init__(nombre, ID, sueldo)
        self.__produccion = None
        self.__guion = guion

    def get_produccion(self):
        return self.__produccion
    
    def set_produccion(self, newproduccion):
        self.__produccion = newproduccion

    def get_guion(self):
        return self.__guion
    
    def set_guion(self, newguion):
        self.__guion = newguion