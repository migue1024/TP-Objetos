from actor_camarografo import Actor_Camarografo

class Actor(Actor_Camarografo):
    def __init__(self, nombre, ID, sueldo, guion):
        super().__init__(nombre, ID, sueldo)
        self.__guion = guion
    
    def get_guion(self):
        return self.__guion
    
    def set_guion(self, newguion):
        self.__guion = newguion

    def hacerAudicion(self):
        print("Estoy hacuendo una audicion")

    def actuar(self):
        print("Estoy actuando")