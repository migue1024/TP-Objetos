from actor_camarografo import Actor_Camarografo

class Camarografo(Actor_Camarografo):
    def __init__(self, nombre, ID, sueldo):
        super().__init__(nombre, ID, sueldo)

    def filmar(self):
        print("Estoy filmando")

    def organizarIluminacion(self):
        print("Estoy organizando la iluminacion")