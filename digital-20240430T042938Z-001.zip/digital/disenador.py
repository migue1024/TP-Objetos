from empleado import Empleado

class Diseniador(Empleado):
    def __init__(self, nombre, ID, sueldo):
        super().__init__(nombre, ID, sueldo)

    def diseniar(self):
        print("Estoy diseniando")

    def trabajarMaqueta(self):
        print("Estoy trabajando en una maqueta")