from produccion import Produccion

class Documental(Produccion):
    def __init__(self, nombre, fechaEstreno):
        super().__init__(nombre, fechaEstreno)

    def validarDocumentacion(self):
        print("Estamos validando la documentacion")