from produccion import Produccion

class StopMotion(Produccion):
    def __init__(self, nombre, fechaEstreno):
        super().__init__(nombre, fechaEstreno)

    def realizarPrueba(self):
        print("Estamos realizacion la prueba")