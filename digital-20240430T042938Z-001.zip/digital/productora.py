class Productora():
    def __init__(self):
        self.__conjuntoProducciones = []
        self.__esquemaEmpleados = []

    def get_conjuntoProducciones(self):
        return self.__conjuntoProducciones
    
    def set_conjuntoProducciones(self, newconjunto):
        self.__conjuntoProducciones = newconjunto

    def get_esquemaEmpleados(self):
        return self.__esquemaEmpleados
    
    def set_esquemaEmpleados(self, newesquema):
        self.__esquemaEmpleados = newesquema

    def liquidarSueldo(self, empleadoObj):
        print(empleadoObj.get_sueldo())