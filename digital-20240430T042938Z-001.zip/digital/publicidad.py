from produccion import Produccion

class Publicidad(Produccion):
    def __init__(self, nombre, fechaEstreno, manualMarca):
        super().__init__(nombre, fechaEstreno)
        self.__manualMarca = manualMarca

    def get_manualMarca(self):
        return self.__manualMarca
    
    def set_manualMarca(self, newmanual):
        self.__manualMarca = newmanual