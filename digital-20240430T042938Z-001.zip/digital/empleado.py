class Empleado():
    def __init__(self, nombre, ID, sueldo):
        self.__nombre = nombre
        self.__ID = ID
        self.__sueldo = sueldo
    
    def get_nombre(self):
        return self.__nombre
    
    def set_nombre(self, newnombre):
        self.__nombre = newnombre

    def get_ID(self):
        return self.__ID
    
    def set_ID(self, newid):
        self.__ID = newid

    def get_sueldo(self):
        return self.__sueldo
    
    def set_sueldo(self, newsueldo):
        self.__sueldo = newsueldo

    def responder(self):
        print("Estoy haciendo mi trabajo")